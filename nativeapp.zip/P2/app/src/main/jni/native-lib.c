#include <jni.h>

JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_initMemoryManager(JNIEnv *env, jobject instance,
                                                     jint maxAllocationSize) {

    // TODO

}